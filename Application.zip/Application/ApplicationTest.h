#ifndef APPLICATIONTEST_H
#define APPLICATIONTEST_H

#include <iostream>
#include "Application.h"

using namespace std;

/**
 * @class ApplicationTest
 * @brief Unit testing for all Application class functions
 *
 *
 * @author Zhi Guang
 * @version 01
 * @date 26/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 05/04/2020 Zhi Guang, Changed Test2, Test5 and Test6
 *
 * @bug The program has no bugs
 */

class ApplicationTest
{
    public:
        /**
         * @brief Default constructor
         */
        ApplicationTest();

        /**
         * @brief Default destructor
         */
        virtual ~ApplicationTest();

        /**
         * @brief Create Application class
         *
         * @return void
         */
        void Test1();

        /**
         * @brief Test OpenFile function
         *
         * @return void
         */
        void Test2();

        /**
         * @brief Test setter and getter for m_result
         *
         * @return void
         */
        void Test3();

        /**
         * @brief Test display menu function
         *
         * @return void
         */
        void Test4();

        /**
         * @brief Test functions to insert to map and bst
         *
         * @return void
         */
        void Test5();

        /**
         * @brief Test RunApp function
         *
         * @return void
         */
        void Test6();

    protected:

    private:
};

#endif // APPLICATIONTEST_H
