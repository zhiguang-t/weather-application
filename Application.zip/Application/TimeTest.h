#ifndef TIMETEST_H
#define TIMETEST_H

#include <iostream>
#include "Time.h"

using namespace std;

/**
 * @class TimeTest
 * @brief Unit testing for all Time class functions
 *
 *
 * @author Zhi Guang
 * @version 01
 * @date 23/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 05/04/2020 Zhi Guang, Added tests for invalid input; added Test3
 *
 * @bug The program has no bugs
 */

class TimeTest
{
    public:
        /**
         * @brief Default constructor
         */
        TimeTest();

        /**
         * @brief Default destructor
         */
        virtual ~TimeTest();

        /**
         * @brief Create Time class
         *
         * @return void
         */
        void Test1();

        /**
         * @brief Testing setter and getter functions
         *
         * @return void
         */
        void Test2();

        /**
         * @brief Testing comparison operator
         *
         * @return void
         */
        void Test3();

    protected:

    private:
};

#endif // TIMETEST_H
