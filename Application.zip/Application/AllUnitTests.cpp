#include "AllUnitTests.h"

AllUnitTests::AllUnitTests()
{
    cout << "---------------------------------------------------" << endl;
    cout << "Conducting Unit Tests" << endl;;
    cout << "---------------------------------------------------" << endl << endl;
}

AllUnitTests::~AllUnitTests()
{}

void AllUnitTests::Test()
{
    DateTest d;
    d.Test1();
    d.Test2();
    d.Test3();
    d.Test4();
    d.Test5();

    TimeTest t;
    t.Test1();
    t.Test2();
    t.Test3();

    WindTempSolarLogTest w;
    w.Test1();
    w.Test2();
    w.Test3();

    BstTest bt;
    bt.Test1();
    bt.Test2();
    bt.Test3();
    bt.Test4();
    bt.Test5();
    bt.Test6();
    bt.Test7();
    bt.Test8();
    bt.Test9();
    bt.Test10();
    bt.Test11();
    bt.Test12();
    bt.Test13();
    bt.Test14();
    bt.Test15();
    bt.Test16();
    bt.Test17();
    bt.Test18();
    bt.Test19();
    bt.Test20();
    bt.Test21();
    bt.Test22();
    bt.Test23();

    ApplicationTest a;
    a.Test1();
    a.Test2();
    a.Test3();
    a.Test4();
    a.Test5();
    a.Test6();
}
