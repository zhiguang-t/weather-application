#ifndef WINDTEMPSOLARLOGTEST_H
#define WINDTEMPSOLARLOGTEST_H

#include <iostream>
#include "WindTempSolarLog.h"

using namespace std;

/**
 * @class WindTempSolarLogTest
 * @brief Manage all WindTempSolarLog unit tests
 *
 * @author Zhi Guang
 * @version 01
 * @date 26/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 05/04/2020 Zhi Guang, Added tests for invalid input
 *
 * @bug The program has no bugs
 */

class WindTempSolarLogTest
{
    public:
        /**
         * @brief Default constructor
         */
        WindTempSolarLogTest();

        /**
         * @brief Default destructor
         */
        virtual ~WindTempSolarLogTest();

        /**
         * @brief Test constructor
         *
         * @return void
         */
        void Test1();

        /**
         * @brief Test setters and getters
         *
         * @return void
         */
        void Test2();

        /**
         * @brief Test SetWindTempSolarLog function
         *
         * @return void
         */
        void Test3();

    protected:

    private:
};

#endif // WINDTEMPSOLARLOGTEST_H
