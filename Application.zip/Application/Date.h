#ifndef DATE_H
#define DATE_H

#include <iostream>
#include <string>

using namespace std;

/**
 * @class Date
 * @brief Manage all date
 *
 * @author Zhi Guang
 * @version 01
 * @date 10/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 24/02/2020 Zhi Guang, Added ConvertMonth
 *
 * @author Zhi Guang
 * @version 03
 * @date 16/03/2020 Zhi Guang, Added comparison operators
 *
 * @author Zhi Guang
 * @version 04
 * @date 05/04/2020 Zhi Guang, Added ValidDate function
 *
 * @bug The program has no bugs
 */

class Date
{
    public:
        /**
         * @brief Default constructor
         *
         * Initialise day, month and year to 0
         */
        Date();

        /**
         * @brief Constructor to initialise all values of Date
         *
         * @param d - day of date
         * @param m - month of date
         * @param y - year of date
         */
        Date(int d, int m, int y);

        /**
         * @brief Sets day of date
         *
         * @param d - integer day of date
         * @return void
         * @pre d must be integer
         */
        void SetDay(int d);

        /**
         * @brief Sets month of date
         *
         * @param m - month of date
         * @return void
         * @pre m must be integer
         */
        void SetMonth(int m);

        /**
         * @brief Sets year of date
         *
         * @param y - year of date
         * @return void
         * @pre y must have contents
         */
        void SetYear(int y);

        /**
         * @brief Returns day
         *
         * @return m_day - day of date
         */
        int GetDay() const;

        /**
         * @brief Returns month
         *
         * @return m_month - month of date
         */
        int GetMonth() const;

        /**
         * @brief Returns year
         *
         * @return m_year - year of date
         */
        int GetYear() const;

        /**
         * @brief Convert month from integer to string
         *
         * @param i - integer month
         * @param &m - variable to store converted month
         * @return void
         */
        void ConvertMonth(int i, string &m);

        /**
         * @brief Check if a date is valid
         *
         * @param d - day of date
         * @param m - month of date
         * @param y - year of date
         * @return true if date is valid; false otherwise
         */
        bool ValidDate(const int d, const int m, const int y);

    protected:

    private:
        /// Day of date
        int m_day;
        /// Year of date
        int m_year;
        /// Month of date
        int m_month;
};

ostream & operator <<( ostream & os, const Date & D );

istream & operator >>( istream & input, Date & D );

bool operator <(const Date &L, const Date &R);

bool operator >(const Date &L, const Date &R);

bool operator ==(const Date &L, const Date &R);

#endif // DATE_H
