#include "ApplicationTest.h"

ApplicationTest::ApplicationTest()
{
    cout << "---------------------------------------------------" << endl;
    cout << "Tests for Application class" << endl;;
    cout << "---------------------------------------------------" << endl << endl;
}

ApplicationTest::~ApplicationTest()
{}

void ApplicationTest::Test1()
{
    cout << "Test 1 - Create Application class" << endl;
    Application a;
    cout << "Application created" << endl << endl << endl;
}

void ApplicationTest::Test2()
{
    cout << "Test 2 - Test OpenFile function" << endl;
    Application a;
    bool check;

    cout << "Opening valid file" << endl;
    check = a.OpenFile("data/test.txt", a);
    if(check == true)
    {
        cout << "File opened and read" << endl << endl;
    }
    else
    {
        cout << "File not read" << endl << endl;
    }

    cout << "Opening invalid file" << endl;
    check = a.OpenFile("data/testing.txt", a);
    if(check == true)
    {
        cout << "File opened and read" << endl << endl;
    }
    else
    {
        cout << "File not read" << endl << endl;
    }

    cout << "Both tests pass" << endl << endl << endl;
}

void ApplicationTest::Test3()
{
    cout << "Test 3 - Test setters and getters" << endl;
    Application a;

    a.AddToResult("testing");
    cout << "tesing added to m_result" << endl << endl;

    string temp;
    a.GetResult(temp);
    cout << "Content of m_result: " << temp << endl << endl;

    cout << "Test pass" << endl << endl << endl;
}

void ApplicationTest::Test4()
{
    cout << "Test 4 - Displaying menu" << endl;
    Application a;
    a.Menu();
    cout << endl << endl << endl;
}

void ApplicationTest::Test5()
{
    cout << "Test 5 - Test InsertToMap and InsertToBst function" << endl;
    Application a;
    WindTempSolarLog test;

    a.InsertToMap("test", test);
    cout << "Key-value pair successfully inserted into map" << endl << endl;

    a.InsertToBst("test");
    cout << "string successfully inserted into bst" << endl << endl;

    cout << "Both tests pass" << endl << endl << endl;
}

void ApplicationTest::Test6()
{
    cout << "Test 6 - Testing RunApp" << endl;
    Application a;

    cout << "Testing RunApp with invalid file" << endl;
    bool check = a.OpenFile("data/testing.txt", a);
    a.RunApp(a, check);

    cout << "\nRunApp did not execute" << endl << endl;

    cout << "Test pass" << endl << endl;

    cout << "Testing RunApp with MetData_Mar01-2014-Mar01-2015-ALL.csv" << endl;
    check = a.OpenFile("data/test.txt", a);
    a.RunApp(a, check);
}

