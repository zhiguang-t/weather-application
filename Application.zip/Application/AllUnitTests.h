#ifndef ALLUNITTESTS_H
#define ALLUNITTESTS_H

#include <iostream>
#include "DateTest.h"
#include "TimeTest.h"
#include "WindTempSolarLogTest.h"
#include "ApplicationTest.h"
#include "BstTest.h"

using namespace std;

/**
 * @class AllUnitTests
 * @brief Manage all unit tests
 *
 * @author Zhi Guang
 * @version 01
 * @date 26/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 06/04/2020 Zhi Guang, Updated class with new test cases
 *
 * @bug The program has no bugs
 */

class AllUnitTests
{
    public:
        /**
         * @brief Default constructor
         */
        AllUnitTests();

        /**
         * @brief Default destructor
         */
        virtual ~AllUnitTests();

        /**
         * @brief Unit tests for all classes
         *
         * @return void
         */
        void Test();

    protected:

    private:
};

#endif // ALLUNITTESTS_H
