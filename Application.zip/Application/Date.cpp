#include "Date.h"

Date::Date()
{}

Date::Date(int d, int m, int y)
{
    m_day = d;
    m_month = m;
    m_year = y;
}

void Date::SetDay(int d)
{
    m_day = d;
}

void Date::SetMonth(int m)
{
    m_month = m;
}

void Date::SetYear(int y)
{
    m_year = y;
}

int Date::GetDay() const
{
    return m_day;
}

int Date::GetMonth() const
{
    return m_month;
}

int Date::GetYear() const
{
    return m_year;
}

// Function to convert integer month to string month
void Date::ConvertMonth(int i, string &m)
{
    switch(i)
    {
        case 1:
            m = "January";
            break;
        case 2:
            m = "February";
            break;
        case 3:
            m = "March";
            break;
        case 4:
            m = "April";
            break;
        case 5:
            m = "May";
            break;
        case 6:
            m = "June";
            break;
        case 7:
            m = "July";
            break;
        case 8:
            m = "August";
            break;
        case 9:
            m = "September";
            break;
        case 10:
            m = "October";
            break;
        case 11:
            m = "November";
            break;
        case 12:
            m = "December";
            break;
        default:
            m = "Invalid";
    }
}

// Function to check if date is valid
bool Date::ValidDate(const int d, const int m, const int y)
{
    // Check for positive year
    if(y <= 0)
    {
        return false;
    }
    // Check for valid month
    else if(m<1 || m>12)
    {
        return false;
    }
    // Check for valid day for months with 31 days
    else if(m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12)
    {
        if(d<1 || d>31)
        {
            return false;
        }
    }
    // Check for valid day for months with 30 days
    else if(m == 4 || m == 6 || m == 9 || m == 11)
    {
        if(d<1 || d>30)
        {
            return false;
        }
    }
    // Checking February
    else
    {
        // Check for leap year
        if(y%4 == 0 && y%400 == 0)
        {
            if(d<1 || d>29)
            {
                return false;
            }
        }
        else if(y%4 == 0 && y%100 != 0)
        {
            if(d<1 || d>29)
            {
                return false;
            }
        }
        // Check for valid day
        else if(d<1 || d>28)
        {
            return false;
        }
    }

    return true;
}

ostream & operator <<( ostream & os, const Date & D )
{
    os << to_string(D.GetDay()) + "/" + to_string(D.GetMonth()) + "/" + to_string(D.GetYear());

    return os;
}

istream & operator >>( istream & input, Date & D )
{
    return input;
}

bool operator <(const Date &L, const Date &R)
{
    if((L.GetYear() < R.GetYear()) ||
       (L.GetYear() == R.GetYear() && L.GetMonth() < R.GetMonth()) ||
       (L.GetYear() == R.GetYear() && L.GetMonth() == R.GetMonth() && L.GetDay() < R.GetDay()))
    {
        return true;
    }
    return false;
}

bool operator >(const Date &L, const Date &R)
{
    if((L.GetYear() > R.GetYear()) ||
       (L.GetYear() == R.GetYear() && L.GetMonth() > R.GetMonth()) ||
       (L.GetYear() == R.GetYear() && L.GetMonth() == R.GetMonth() && L.GetDay() > R.GetDay()))
    {
        return true;
    }
    return false;
}

bool operator ==(const Date &L, const Date &R)
{
    return (L.GetYear() == R.GetYear() && L.GetMonth() == R.GetMonth() && L.GetDay() == R.GetDay());
}

