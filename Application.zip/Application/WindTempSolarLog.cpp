#include "WindTempSolarLog.h"

WindTempSolarLog::WindTempSolarLog()
{}

WindTempSolarLog::~WindTempSolarLog()
{}

void WindTempSolarLog::SetWindTempSolarLog(WindTempSolarLog w)
{
    m_date = w.GetDate();
    m_time = w.GetTime();
    m_wind_speed = w.GetWindSpeed();
    m_solar_radiation = w.GetSolarRadiation();
    m_temperature = w.GetTemperature();
}

void WindTempSolarLog::SetDate(Date d)
{
    m_date = d;
}

void WindTempSolarLog::SetTime(Time t)
{
    m_time = t;
}

void WindTempSolarLog::SetWindSpeed(float w)
{
    m_wind_speed = w;
}

void WindTempSolarLog::SetSolarRadiation(float s)
{
    m_solar_radiation = s;
}

void WindTempSolarLog::SetTemperature(float t)
{
    m_temperature = t;
}

Date WindTempSolarLog::GetDate() const
{
    return m_date;
}

Time WindTempSolarLog::GetTime() const
{
    return m_time;
}

float WindTempSolarLog::GetWindSpeed() const
{
    return m_wind_speed;
}

float WindTempSolarLog::GetSolarRadiation() const
{
    return m_solar_radiation;
}

float WindTempSolarLog::GetTemperature() const
{
    return m_temperature;
}
