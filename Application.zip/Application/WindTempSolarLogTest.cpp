#include "WindTempSolarLogTest.h"

WindTempSolarLogTest::WindTempSolarLogTest()
{
    cout << "---------------------------------------------------" << endl;
    cout << "Tests for WindTempSolarLog class" << endl;;
    cout << "---------------------------------------------------" << endl << endl;
}

WindTempSolarLogTest::~WindTempSolarLogTest()
{}

void WindTempSolarLogTest::Test1()
{
    cout << "Test 1 - Create WindTempSolarLog class" << endl;
    WindTempSolarLog l;
    cout << "WindTempSolarLog created" << endl << endl << endl;
}

void WindTempSolarLogTest::Test2()
{
    cout << "Test 2 - Setters and getters" << endl;
    WindTempSolarLog l;
    Date d;
    d.SetDay(1);
    d.SetMonth(1);
    d.SetYear(2000);
    l.SetDate(d);
    Time t;
    t.SetHour(2);
    t.SetMinute(40);
    l.SetTime(t);
    l.SetSolarRadiation(3);
    l.SetTemperature(43);
    l.SetWindSpeed(4.3);

    cout << "WindTempSolarLog set with Date: 1/1/2000, Time: 2:40, solar: 3, temperature: 43 and wind speed: 4.3" << endl << endl;
    cout << "WindTempSolarLog values: " << endl;
    cout << "Date: " << l.GetDate().GetDay() << "/" << l.GetDate().GetMonth() << "/" << l.GetDate().GetYear() << endl;
    cout << "Time: " << l.GetTime().GetHour() << ":" << l.GetTime().GetMinute() << endl;
    cout << "solar radiation: " << l.GetSolarRadiation() << endl;
    cout << "temperature: " << l.GetTemperature() << endl;
    cout << "wind speed: " << l.GetWindSpeed() << endl << endl;

    d.SetDay(-2);
    d.SetMonth(-2);
    d.SetYear(-3);
    l.SetDate(d);

    t.SetHour(-2);
    t.SetMinute(-3);
    l.SetTime(t);
    l.SetSolarRadiation(-32);
    l.SetTemperature(-3);
    l.SetWindSpeed(-32.3);

    cout << "WindTempSolarLog set with Date: -2/-2/-3, Time: -2:-3, solar: -32, temperature: -3 and wind speed: -32.3" << endl << endl;
    cout << "WindTempSolarLog values: " << endl;
    cout << "Date: " << l.GetDate().GetDay() << "/" << l.GetDate().GetMonth() << "/" << l.GetDate().GetYear() << endl;
    cout << "Time: " << l.GetTime().GetHour() << ":" << l.GetTime().GetMinute() << endl;
    cout << "solar radiation: " << l.GetSolarRadiation() << endl;
    cout << "temperature: " << l.GetTemperature() << endl;
    cout << "wind speed: " << l.GetWindSpeed() << endl << endl;

    cout << "Invalid values are accepted as no error checking is done" << endl << endl;
    cout << "All tests pass" << endl << endl << endl;
}

void WindTempSolarLogTest::Test3()
{
    cout << "Test 3 - Test SetWindTempSolarLog function" << endl;
    WindTempSolarLog w;
    Date d;
    d.SetDay(1);
    d.SetMonth(1);
    d.SetYear(2000);
    w.SetDate(d);
    Time t;
    t.SetHour(2);
    t.SetMinute(40);
    w.SetTime(t);
    w.SetSolarRadiation(3);
    w.SetTemperature(43);
    w.SetWindSpeed(4.3);

    WindTempSolarLog l;
    l.SetWindTempSolarLog(w);

    cout << "WindTempSolarLog set another WindTempSolarLog with Date: 1/1/2000, Time: 2:40, solar: 3, temperature: 43 and wind speed: 4.3" << endl << endl;
    cout << "WindTempSolarLog values: " << endl;
    cout << "Date: " << l.GetDate().GetDay() << "/" << l.GetDate().GetMonth() << "/" << l.GetDate().GetYear() << endl;
    cout << "Time: " << l.GetTime().GetHour() << ":" << l.GetTime().GetMinute() << endl;
    cout << "solar radiation: " << l.GetSolarRadiation() << endl;
    cout << "temperature: " << l.GetTemperature() << endl;
    cout << "wind speed: " << l.GetWindSpeed() << endl;
    cout << endl << endl;
}
