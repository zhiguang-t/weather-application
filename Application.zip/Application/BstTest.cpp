#include "BstTest.h"

BstTest::BstTest()
{
    cout << "-----------------------------------------------------" << endl;
    cout << "Template BST test" <<endl;
    cout << "-----------------------------------------------------" << endl << endl;
}

BstTest::~BstTest()
{}

void BstTest::Test1()
{
    cout << "-----------------------------------------------------" << endl;
    cout << "Integer BST test" <<endl;
    cout << "-----------------------------------------------------" << endl << endl;

    cout << "Test 1 - Test constructor and destructor" << endl;
    Bst<int> t;
    cout << "Integer Bst created and destroyed successfully" << endl << endl << endl;
}

void BstTest::Test2()
{
    cout << "Test 2 - Test Insert function with root unoccupied" << endl;
    Bst<int> t;
    t.Insert(2);
    cout << "Integer 2 successfully inserted into root" << endl << endl << endl;
}

void BstTest::Test3()
{
    cout << "Test 3 - Test Insert function with root occupied" << endl;
    Bst<int> t;
    t.Insert(2);
    t.Insert(1);
    t.Insert(3);
    cout << "Integers 2, 1 and 3 successfully inserted into tree" << endl << endl << endl;
}

void BstTest::Test4()
{
    cout << "Test 4 - Test in-order traversal" << endl;
    Bst<int> t;
    t.Insert(23);
    t.Insert(12);
    t.Insert(31);
    t.Insert(3);
    t.Insert(15);
    t.Insert(29);
    t.Insert(88);
    t.Insert(7);
    t.Insert(13);
    t.Insert(19);
    t.Insert(25);
    t.Insert(53);

    t.InOrder();

    cout << endl << "Integers in tree are in correct order" << endl << endl << endl;
}

void BstTest::Test5()
{
    cout << "Test 5 - Test pre-order traversal" << endl;
    Bst<int> t;
    t.Insert(23);
    t.Insert(12);
    t.Insert(31);
    t.Insert(3);
    t.Insert(15);
    t.Insert(29);
    t.Insert(88);
    t.Insert(7);
    t.Insert(13);
    t.Insert(19);
    t.Insert(25);
    t.Insert(53);

    t.PreOrder();

    cout << endl << "Integers in tree are in correct order" << endl << endl << endl;
}

void BstTest::Test6()
{
    cout << "Test 6 - Test post-order traversal" << endl;
    Bst<int> t;
    t.Insert(23);
    t.Insert(12);
    t.Insert(31);
    t.Insert(3);
    t.Insert(15);
    t.Insert(29);
    t.Insert(88);
    t.Insert(7);
    t.Insert(13);
    t.Insert(19);
    t.Insert(25);
    t.Insert(53);

    t.PostOrder();

    cout << endl << "Integers in tree are in correct order" << endl << endl << endl;
}


void BstTest::Test7()
{
    cout << "Test 7 - Test search function with empty tree" << endl;
    Bst<int> t;

    cout << "Search for 3 in BST. Expected: false. Actual: " << t.Search(3) << "." << endl << endl << endl;
}

void BstTest::Test8()
{
    cout << "Test 8 - Test search function with occupied tree" << endl;
    Bst<int> t;
    t.Insert(23);
    t.Insert(12);
    t.Insert(31);
    t.Insert(3);
    t.Insert(15);
    t.Insert(29);
    t.Insert(88);
    t.Insert(7);
    t.Insert(13);
    t.Insert(19);
    t.Insert(25);
    t.Insert(53);

    t.PreOrder();
    cout << endl << endl << "Search for 3 in BST. Expected: true. Actual: " << t.Search(3) << "." << endl;
    cout << "Search for 100 in BST. Expected: false. Actual: " << t.Search(100) << "." << endl;
    cout << "Both tests pass" <<endl << endl << endl;
}

void BstTest::Test9()
{
    cout << "Test 9 - Test delete function with empty tree" << endl;
    Bst<int> t;
    t.Delete(12);
    cout << "Nothing deleted" <<endl << endl << endl;
}

void BstTest::Test10()
{
    cout << "Test 10 - Test delete function with filled tree" << endl;
    Bst<int> t;
    t.Insert(23);
    t.Insert(12);
    t.Insert(31);
    t.Insert(3);
    t.Insert(15);
    t.Insert(29);
    t.Insert(88);
    t.Insert(7);
    t.Insert(13);
    t.Insert(19);
    t.Insert(25);
    t.Insert(53);

    cout << "Pre-order: " <<endl;
    t.PreOrder();
    t.Delete(100);
    cout << endl << endl << "After deleting 100 from tree: " << endl;
    t.PreOrder();
    cout << endl << "Nothing deleted as 100 is not in tree" << endl;
    t.Delete(12);
    cout << endl << "After deleting 12 from tree: " << endl;
    t.PreOrder();
    cout << endl << "Node and all child nodes are deleted" <<endl << endl << endl;
}

void BstTest::Test11()
{
    cout << "Test 11 - Test GetData function" << endl;
    Bst<int> t;
    int num = 0;
    bool found = t.GetData(5, num);
    cout << endl << "Get data from unoccupied tree. Expected: false. Actual: " << found << endl;

    t.Insert(23);
    t.Insert(12);
    t.Insert(31);
    t.Insert(3);
    t.Insert(15);
    t.Insert(29);
    t.Insert(88);
    t.Insert(7);
    t.Insert(13);
    t.Insert(19);
    t.Insert(25);
    t.Insert(53);

    cout << endl << "Tree with following values: " << endl;
    t.PreOrder();

    num = 0;
    found = t.GetData(3, num);
    cout << endl << endl << "Get 3 in BST. Expected: 3. Actual: " << found << ", " << num << "." << endl;

    num = 0;
    found = t.GetData(100, num);
    cout << "Get 100 in BST. Expected: false. Actual: " << found << "." << endl;
    cout << "Both tests pass" <<endl << endl << endl;
}

void BstTest::Test12()
{
    cout << "-----------------------------------------------------" << endl;
    cout << "Date BST test" <<endl;
    cout << "-----------------------------------------------------" << endl << endl;

    cout << "Test 12 - Test constructor and destructor" << endl;
    Bst<Date> t;
    cout << "Date Bst created and destroyed successfully" << endl << endl << endl;
}

void BstTest::Test13()
{
    cout << "Test 13 - Test Insert function with root unoccupied" << endl;
    Bst<Date> t;

    Date d = Date(1, 1, 2010);

    t.Insert(d);

    cout << "Date 1/1/2010 inserted in tree successfully" << endl << endl << endl;
}

void BstTest::Test14()
{
    cout << "Test 14 - Test Insert function with root occupied" << endl;
    Bst<Date> t;

    Date d = Date(1, 1, 2010);
    Date d2 = Date(2, 1, 2010);

    t.Insert(d);
    t.Insert(d2);

    cout << "Dates " << d << " and " << d2 << " successfully inserted into tree" << endl << endl << endl;
}

void BstTest::Test15()
{
    cout << "Test 15 - Test in-order traversal" << endl;
    Bst<Date> t;

    Date d1 = Date(6, 6, 2016);
    Date d2 = Date(4, 5, 2013);
    Date d3 = Date(7, 9, 2019);
    Date d4 = Date(23, 10, 2017);
    Date d5 = Date(20, 5, 2015);
    Date d6 = Date(15, 2, 2015);
    Date d7 = Date(5, 8, 2010);
    Date d8 = Date(4, 5, 2020);
    Date d9 = Date(22, 5, 2015);

    t.Insert(d1);
    t.Insert(d2);
    t.Insert(d3);
    t.Insert(d4);
    t.Insert(d5);
    t.Insert(d6);
    t.Insert(d7);
    t.Insert(d8);
    t.Insert(d9);

    t.InOrder();

    cout << endl << "Dates in tree are in correct order" << endl << endl << endl;
}

void BstTest::Test16()
{
    cout << "Test 16 - Test pre-order traversal" << endl;
    Bst<Date> t;

    Date d1 = Date(6, 6, 2016);
    Date d2 = Date(4, 5, 2013);
    Date d3 = Date(7, 9, 2019);
    Date d4 = Date(23, 10, 2017);
    Date d5 = Date(20, 5, 2015);
    Date d6 = Date(15, 2, 2015);
    Date d7 = Date(5, 8, 2010);
    Date d8 = Date(4, 5, 2020);
    Date d9 = Date(22, 5, 2015);

    t.Insert(d1);
    t.Insert(d2);
    t.Insert(d3);
    t.Insert(d4);
    t.Insert(d5);
    t.Insert(d6);
    t.Insert(d7);
    t.Insert(d8);
    t.Insert(d9);

    t.PreOrder();

    cout << endl << "Dates in tree are in correct order" << endl << endl << endl;
}

void BstTest::Test17()
{
    cout << "Test 17 - Test post-order traversal" << endl;
    Bst<Date> t;

    Date d1 = Date(6, 6, 2016);
    Date d2 = Date(4, 5, 2013);
    Date d3 = Date(7, 9, 2019);
    Date d4 = Date(23, 10, 2017);
    Date d5 = Date(20, 5, 2015);
    Date d6 = Date(15, 2, 2015);
    Date d7 = Date(5, 8, 2010);
    Date d8 = Date(4, 5, 2020);
    Date d9 = Date(22, 5, 2015);

    t.Insert(d1);
    t.Insert(d2);
    t.Insert(d3);
    t.Insert(d4);
    t.Insert(d5);
    t.Insert(d6);
    t.Insert(d7);
    t.Insert(d8);
    t.Insert(d9);

    t.PostOrder();

    cout << endl << "Dates in tree are in correct order" << endl << endl << endl;
}

void BstTest::Test18()
{
    cout << "Test 18 - Test search function with empty tree" << endl;
    Bst<Date> t;

    cout << "Search for 1/1/2013 in BST. Expected: false. Actual: " << t.Search(Date(1, 1, 2013)) << "." << endl << endl << endl;
}

void BstTest::Test19()
{
    cout << "Test 19 - Test search function with occupied tree" << endl;
    Bst<Date> t;

    Date d1 = Date(6, 6, 2016);
    Date d2 = Date(4, 5, 2013);
    Date d3 = Date(7, 9, 2019);
    Date d4 = Date(23, 10, 2017);
    Date d5 = Date(20, 5, 2015);
    Date d6 = Date(15, 2, 2015);
    Date d7 = Date(5, 8, 2010);
    Date d8 = Date(4, 5, 2020);
    Date d9 = Date(22, 5, 2015);

    t.Insert(d1);
    t.Insert(d2);
    t.Insert(d3);
    t.Insert(d4);
    t.Insert(d5);
    t.Insert(d6);
    t.Insert(d7);
    t.Insert(d8);
    t.Insert(d9);

    t.PreOrder();
    cout << endl << endl << "Search for 5/8/2010 in BST. Expected: true. Actual: " << t.Search(Date(5, 8, 2010)) << "." << endl;
    cout << "Search for 1/1/2010 in BST. Expected: false. Actual: " << t.Search(Date(1, 1, 2010)) << "." << endl;
    cout << "Both tests pass" <<endl << endl << endl;
}

void BstTest::Test20()
{
    cout << "Test 20 - Test delete function with empty tree" << endl;
    Bst<Date> t;
    t.Delete(Date(1, 1, 2010));
    cout << "Nothing deleted" <<endl << endl << endl;
}

void BstTest::Test21()
{
    cout << "Test 21 - Test delete function with filled tree" << endl;
    Bst<Date> t;

    Date d1 = Date(6, 6, 2016);
    Date d2 = Date(4, 5, 2013);
    Date d3 = Date(7, 9, 2019);
    Date d4 = Date(23, 10, 2017);
    Date d5 = Date(20, 5, 2015);
    Date d6 = Date(15, 2, 2015);
    Date d7 = Date(5, 8, 2010);
    Date d8 = Date(4, 5, 2020);
    Date d9 = Date(22, 5, 2015);

    t.Insert(d1);
    t.Insert(d2);
    t.Insert(d3);
    t.Insert(d4);
    t.Insert(d5);
    t.Insert(d6);
    t.Insert(d7);
    t.Insert(d8);
    t.Insert(d9);

    cout << "Pre-order: " <<endl;
    t.PreOrder();
    t.Delete(Date(1, 1, 2010));
    cout << endl << endl << "After deleting 1/1/2010 from tree: " << endl;
    t.PreOrder();
    cout << endl << "Nothing deleted as 1/1/2010 is not in tree" << endl;
    t.Delete(Date(20, 5, 2015));
    cout << endl << "After deleting 20/5/2015 from tree: " << endl;
    t.PreOrder();
    cout << endl << "Node and all child nodes are deleted" <<endl << endl << endl;
}

void BstTest::Test22()
{
    cout << "Test 22 - Test GetData function" << endl;
    Bst<Date> t;

    Date d;
    bool found = t.GetData(Date(1, 1, 2010), d);

    cout << endl << "Get data from unoccupied tree. Expected: false. Actual: " << found << endl;

    Date d1 = Date(6, 6, 2016);
    Date d2 = Date(4, 5, 2013);
    Date d3 = Date(7, 9, 2019);
    Date d4 = Date(23, 10, 2017);
    Date d5 = Date(20, 5, 2015);
    Date d6 = Date(15, 2, 2015);
    Date d7 = Date(5, 8, 2010);
    Date d8 = Date(4, 5, 2020);
    Date d9 = Date(22, 5, 2015);

    t.Insert(d1);
    t.Insert(d2);
    t.Insert(d3);
    t.Insert(d4);
    t.Insert(d5);
    t.Insert(d6);
    t.Insert(d7);
    t.Insert(d8);
    t.Insert(d9);

    cout << endl << "Tree with following values: " << endl;
    t.PreOrder();

    found = t.GetData(Date(5, 8, 2010), d);
    cout << endl << endl << "Search for 5/8/2010 in BST. Expected: 5/8/2010. Actual: " << found << ", " << d << "." << endl;

    d = Date(0, 0, 0);
    found = t.GetData(Date(1, 1, 2010), d);
    cout << "Search for 1/1/2010 in BST. Expected: false. Actual: " << found << "." << endl;
    cout << "Both tests pass" <<endl << endl << endl;
}

// Function that adds 5 to all data in tree
void AddToNode(int &item)
{
    item = item + 5;
}

void BstTest::Test23()
{
    cout << "-----------------------------------------------------" << endl;
    cout << "Test function pointer on integer BST" <<endl;
    cout << "-----------------------------------------------------" << endl << endl;

    cout << "Test 23 - Test function pointer operation using user defined function" << endl;
    Bst<int> t;

    t.Insert(23);
    t.Insert(12);
    t.Insert(31);
    t.Insert(3);
    t.Insert(15);
    t.Insert(29);
    t.Insert(88);
    t.Insert(7);
    t.Insert(13);
    t.Insert(19);
    t.Insert(25);
    t.Insert(53);

    cout << endl << "Integers in tree:" << endl;
    t.InOrder();
    cout << endl << endl << "After passing in function defined by user to add 5 to all data in tree:" << endl;

    void (*fp)(int &item) = AddToNode;
    t.Traversal(*fp);
    t.InOrder();

    cout << endl << endl << "All data in tree is increased by 5" << endl << endl << endl;
}
