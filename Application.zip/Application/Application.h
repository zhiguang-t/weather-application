#ifndef APPLICATION_H
#define APPLICATION_H

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Date.h"
#include "Time.h"
#include "WindTempSolarLog.h"
#include "Bst.h"
#include <iterator>
#include <map>

using namespace std;

/**
 * @class Application
 * @brief Application that runs the program to calculate wind log results
 *
 * This class is an application that reads an input file containing wind log
 * information, and calculate the month average for the specified month and/or year.
 *
 * @author Zhi Guang
 * @version 01
 * @date 23/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 26/02/2020 Zhi Guang, Added WindLog vector
 *
 * @author Zhi Guang
 * @version 02
 * @date 05/04/2020 Zhi Guang, Changed structure of program. Removed Vector. Added Bst and map. Added Option 5.
 *
 * @todo Put files in data folder. Copy file name into "met_index.txt".
 *
 * @bug The program has no bugs
 */

class Application
{
    public:
        /**
         * @brief Default constructor
         */
        Application();

        /**
         * @brief Default destructor
         */
        virtual ~Application();

        /**
         * @brief Start application
         *
         * This function starts the application, displaying a menu of options
         * for the user to choose from. The program will then execute the option chosen.
         *
         * @param &app - application to run
         * @param check - result of read file
         * @return void
         */
        void RunApp(Application &app, bool check);

        /**
         * @brief Add string to result for output
         *
         * @param s - string to add
         * @return void
         */
        void AddToResult(string s);

        /**
         * @brief Returns result to output
         *
         * @param &s - string to store result
         * @return void
         */
        void GetResult(string &s) const;

        /**
         * @brief Display menu option
         *
         * @return void
         */
        void Menu();

        /**
         * @brief Open all files contained in text document
         *
         * @param infile - text document containing name of files to open
         * @param &app - application to run
         * @return true if all files are opened successfully; false otherwise
         */
        bool OpenFile(string infile, Application &app);

        /**
         * @brief Insert key-value pair into map
         *
         * @param key - key element of map
         * @param value - value element of map
         * @return void
         */
        void InsertToMap(const string key, const WindTempSolarLog value);

        /**
         * @brief Insert value into bst
         *
         * @param key - value to insert into bst
         * @return void
         */
        void InsertToBst(const string key);

    protected:

    private:
        /// string to store WindLog result for output
        string m_result="";
        /// string to store temporary values
        string temp;
        /// Bst to store key values in map
        Bst<string> m_bst;
        /// multimap to store every record in file
        multimap<string, WindTempSolarLog> m_map_log;
        /// Iterator to loop through map
        multimap<string, WindTempSolarLog>::iterator m_map_itr;
        /// Iterator to loop through map for duplicated records
        multimap<string, WindTempSolarLog>::iterator m_duplicate_itr;
        /// Iterator to store first value of specified month and year found
        multimap<string, WindTempSolarLog>::iterator m_first;

        /**
         * @brief Retrieve user input for menu option
         *
         * @return choice - user input option; 0 if not integer
         */
        int GetOption();

        /**
         * @brief Calculate average wind speed for the month
         *
         * @param &app - application
         * @param m - month
         * @param y - year
         * @return ws/counter*60*60/1000 - average wind speed converted to km/h
         */
        float CalcAvgMonthWindSpeed(Application &app, int m, int y);

        /**
         * @brief Calculate average temperature for the month
         *
         * @param &app - application
         * @param m - month
         * @param y - year
         * @return t/counter - average temperature
         */
        float CalcAvgMonthTemp(Application &app, int m, int y);

        /**
         * @brief Calculate total solar radiation for the month
         *
         * @param &app - application
         * @param m - month
         * @param y - year
         * @return sr/6/1000 - total solar radiation converted to kWh/m^2
         */
        float CalcTotalMonthSolar(Application &app, int m, int y);

        /**
         * @brief Get user input for month
         *
         * The function also checks if the input is a valid month.
         *
         * @return m - month input by user; 0 if not valid
         */
        int MonthInput();

        /**
         * @brief Get user input for year
         *
         * The function also checks if the input is a valid year.
         * If the year is not in the program, it will also be considered
         * as invalid.
         *
         * @return y - year input by user; 0 if not valid
         */
        int YearInput();

        /**
         * @brief Process option chosen by user
         *
         * @param choice - option chosen by user
         * @param &app - application
         * @return void
         */
        void Process(int choice, Application &app);

        /**
         * @brief Performs option 1 of menu
         *
         * @param &app - application
         * @return void
         */
        void Option1(Application &app);

        /**
         * @brief Performs option 2 of menu
         *
         * @param &app - application
         * @return void
         */
        void Option2(Application &app);

        /**
         * @brief Performs option 3 of menu
         *
         * @param &app - application
         * @return void
         */
        void Option3(Application &app);

        /**
         * @brief Preforms option 4 of menu
         *
         * @param &app - application
         * @return void
         */
        void Option4(Application &app);

        /**
         * @brief Output result of option 4 into WindTempSolar.csv
         *
         * @param &app - application containing the result
         * @return void
         */
        void OutputResult(Application &app);

        /**
         * @brief Read file indicated by user
         *
         * @param infile - name of file to read
         * @param &app - application used to read file
         * @return true if file is read; false otherwise
         */
        bool ReadFile(string infile, Application &app);

        /**
         * @brief Get user input date and check if it is valid
         *
         * The program will return user input date through its parameter.
         * A date is also considered invalid if the program does not
         * contain records of that date.
         *
         * @param &d - variable to store day of date
         * @param &m - variable to store month of date
         * @param &y - variable to store year of date
         * @return true if date is valid; false otherwise
         */
        bool DateInput(int &d, int &m, int &y);

        /**
         * @brief Performs option 5 of menu
         *
         * @param &app - application
         * @return void
         */
        void Option5(Application &app);
};

istream & operator >>( istream &input, Application &A);

ostream & operator <<(ostream &output, const Application &A);

#endif // APPLICATION_H
