#ifndef DATETEST_H
#define DATETEST_H
#include "Date.h"

/**
 * @class DateTest
 * @brief Unit testing for all Date class functions
 *
 *
 * @author Zhi Guang
 * @version 01
 * @date 17/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 23/02/2020 Zhi Guang, Changed getDate function to passing address into parameter
 *
 * @author Zhi Guang
 * @version 03
 * @date 05/04/2020 Zhi Guang, Added tests for invalid inputs; added Test4 and Test5
 *
 * @bug The program has no bugs
 */

class DateTest
{
    public:
        /**
         * @brief Default constructor
         */
        DateTest();

        /**
         * @brief Default destructor
         */
        virtual ~DateTest();

        /**
         * @brief Test creating of date class
         *
         * @return void
         */
        void Test1();

        /**
         * @brief Test setters and getters
         *
         * @return void
         */
        void Test2();

        /**
         * @brief Test ConvertMonth function
         *
         * @return void
         */
        void Test3();

        /**
         * @brief Test comparison operators
         *
         * @return void
         */
        void Test4();

        /**
         * @brief Test ValidDate function
         *
         * @return void
         */
        void Test5();

    protected:

    private:
};

#endif // DATETEST_H
