#include "Application.h"

Application::Application()
{}

Application::~Application()
{}

// Function to start application
void Application::RunApp(Application &app, bool check)
{
    if(check == true)
    {
        cout << "Extraction complete." << endl << endl;
        cout << "------------------------------------------------------------------------------------" << endl;

        int choice=0;

        while(choice != 6)
        {
            cout << endl << endl;

            // Display menu
            app.Menu();

            // Get user input option
            choice = app.GetOption();

            // Process option
            Process(choice, app);
        }
    }
}

// Opens all files in specified text document
bool Application::OpenFile(string infile, Application &app)
{
    bool check = true;

    ifstream myFile(infile);

    // Return false if file not opened
    if( !myFile )
    {
        cout << "File " << infile << " not found. " << endl;
        return false;
    }

    cout << "Reading File...Extracting File...";

    while(getline(myFile, temp))
    {
        if(temp.length() > 0)
        {
            check = ReadFile("data/" + temp, app);

            // Return false if file cannot be read
            if(check == false)
            {
                cout << "\n\nFile " << temp << " not found. " << endl << endl;
                cout << "Program terminated. " << endl;
                return false;
            }
        }
    }

    return true;
}

// Function to read file
bool Application::ReadFile(string infile, Application &app)
{
    ifstream myFile(infile);

    // Return false if file not opened
    if( !myFile )
    {
        return false;
    }

    // Stream file to application
    myFile >> app;

    myFile.close();

    return true;
}

// Print menu option to screen
void Application::Menu()
{
    cout << "1. Average wind speed and ambient air temperature for a specified month and year." << endl << endl;
    cout << "2. Average wind speed and ambient air temperature for a specified year." << endl << endl;
    cout << "3. Total solar radiation in kWh/m^2 for each month of a specified year." << endl << endl;
    cout << "4. Average wind speed (km/h), average ambient air temperature and total \n";
    cout << "   solar radiation in kWh/m^2 for each month of a specified year." << endl << endl;
    cout << "5. Time(s) for highest solar radiation for specified date." << endl << endl;
    cout << "6. Exit" << endl << endl;
    cout << "Option: ";
}

// Get user input for option
int Application::GetOption()
{
    int choice;

    try
    {
        getline(cin, temp);
        choice = stoi(temp);
    }
    catch (...)
    {
        cout << "\nEnter integer!" << endl;
        choice = 0;
    }

    return choice;
}

// Process user option
void Application::Process(int choice, Application &app)
{
    cout << endl;
    switch(choice)
    {
        case 1:
            Option1(app);
            break;
        case 2:
            Option2(app);
            break;
        case 3:
            Option3(app);
            break;
        case 4:
            Option4(app);
            break;
        case 5:
            Option5(app);
            break;
        case 6:
            cout << "End of program" << endl;
            break;
        default:
            cout << "Invalid option." << endl << endl << endl;
    }
}

// Get user input for month
int Application::MonthInput()
{
    int m;  // Variable to store month

    try
    {
        getline(cin, temp);
        cout << endl;

        m = stoi(temp);

        if(m < 1 || m > 12)
        {
            cout << "Invalid month!" << endl << endl;
            m = 0; // Reset month
        }
    }
    catch(...)
    {
        cout << "Enter integer!" << endl << endl;
        m = 0; // Reset month
    }

    return m;
}

// Get user input for year
int Application::YearInput()
{
    int y;              // Variable to store year
    int counter = 0;    // counter to check if year entered exists in m_bst
    Date d;             // Creating date to convert month into string format

    try
    {
        // Getting user input
        getline(cin, temp);
        cout << endl;

        // Converting year to integer
        y = stoi(temp);

        for(int i=0; i<13; i++)
        {
            // Converting year into key (monthYear) to check if it exists in m_bst
            d.ConvertMonth(i, temp);
            temp = temp + to_string(y);

            // Increase counter if found
            if(m_bst.Search(temp))
            {
                counter++;
            }
        }

        // Display error message if invalid year
        if(y <= 0)
        {
            cout << "Invalid year!" << endl << endl;
            y = 0; // Reset year
        }
        // Display error message if not found
        else if(counter == 0)
        {
            cout << "Invalid year! Program does not contain records with the year " << y << endl << endl;
            y = 0; // Reset year
        }
    }
    catch(...)
    {
        cout << "Enter integer!" << endl << endl;
        y = 0; // Reset year
    }

    return y;
}

// Function for option 1
void Application::Option1(Application &app)
{
    int month=0;    // Variable to store month
    int year=0;     // Variable to store year
    Date d;         // Creating date to convert month into string format

    // Get month and year input from user
    while(month == 0)
    {
        cout << "Enter month: ";
        month = MonthInput();
    }

    while(year == 0)
    {
        cout << "Enter year: ";
        year = YearInput();
    }

    // Calculating results
    float ws = CalcAvgMonthWindSpeed(app, month, year);
    float deg = CalcAvgMonthTemp(app, month, year);

    // Converting month from integer to string format
    d.ConvertMonth(month, temp);

    // Display calculated result
    if(ws > 0 && deg > 0)
    {
        cout << fixed << setprecision(1);
        cout << temp << " " << year << ": " << ws << " km/h, ";
        cout << deg << " degrees C" << endl;
    }
    else
    {
        cout << temp << " " << year << ": No Data" << endl;
    }
}

// Function to calculate average wind speed
float Application::CalcAvgMonthWindSpeed(Application &app, int m, int y)
{
    float ws=0;                         // Variable to store wind speed
    int counter=0;                      // Variable to count number records found
    WindTempSolarLog temp_log;          // Temporary log to store records retrieved
    bool check = true;                  // Variable used as a flag for duplicated records
    WindTempSolarLog duplicate_log;     // Log to store records retrieved to check for duplicates
    Date d;                             // Creating date to convert month into string format

    // Converting year and month input into key
    d.ConvertMonth(m, temp);
    temp = temp + to_string(y);

    // Iterate through map to look for specified records
    for(m_map_itr = m_map_log.begin(); m_map_itr != m_map_log.end(); ++m_map_itr)
    {
        // If record is found
        if(m_map_itr->first == temp)
        {
            // Retrieving value from map
            temp_log = m_map_itr->second;

            // Set iterator m_first to position of first record found
            if(counter == 0)
            {
                m_first = --m_map_itr;
            }

            // Check for duplicate records
            for(m_duplicate_itr = m_first; m_duplicate_itr != m_map_itr; ++ m_duplicate_itr)
            {
                duplicate_log = m_duplicate_itr->second;

                if(m_duplicate_itr->first == temp && duplicate_log.GetDate() == temp_log.GetDate() && duplicate_log.GetTime() == temp_log.GetTime())
                {
                    check = false;
                }
            }

            // Calculate only if record is not duplicated
            if(check)
            {
                ws += temp_log.GetWindSpeed();
                counter++;
            }

            // Reset check
            check = true;
        }
    }

    if(counter > 0)
    {
        return ws/counter*60*60/1000;
    }
    else
    {
        return 0;
    }
}

// Function to calculate average monthly temperature
float Application::CalcAvgMonthTemp(Application &app, int m, int y)
{
    float t=0;                          // Variable to store temperature
    int counter=0;                      // Variable to count number records found
    WindTempSolarLog temp_log;          // Temporary log to store records retrieved
    bool check = true;                  // Variable used as a flag for duplicated records
    WindTempSolarLog duplicate_log;     // Log to store records retrieved to check for duplicates
    Date d;                             // Creating date to convert month into string format

    // Converting year and month input into key
    d.ConvertMonth(m, temp);
    temp = temp + to_string(y);

    // Iterate through map to look for specified records
    for(m_map_itr = m_map_log.begin(); m_map_itr != m_map_log.end(); ++m_map_itr)
    {
        // If record is found
        if(m_map_itr->first == temp)
        {
            // Retrieving value from map
            temp_log = m_map_itr->second;

            // Set iterator m_first to position of first record found
            if(counter == 0)
            {
                m_first = --m_map_itr;
            }

            // Check for duplicate records
            for(m_duplicate_itr = m_first; m_duplicate_itr != m_map_itr; ++ m_duplicate_itr)
            {
                duplicate_log = m_duplicate_itr->second;

                if(m_duplicate_itr->first == temp && duplicate_log.GetDate() == temp_log.GetDate() && duplicate_log.GetTime() == temp_log.GetTime())
                {
                    check = false;
                }
            }

            // Calculate only if record is not duplicated
            if(check)
            {
                t += temp_log.GetTemperature();
                counter++;
            }

            // Reset check
            check = true;
        }
    }

    if(counter > 0)
    {
        return t/counter;
    }
    else
    {
        return 0;
    }
}

// Function for option 2
void Application::Option2(Application &app)
{
    int year=0;     // Variable to store year

    // Getting year input from user
    while(year == 0)
    {
        cout << "Enter year: ";
        year = YearInput();
    }

    Date d;         // Creating date to convert month into string format
    float WS, deg;  // Variables to store wind speed and temperature respectively

    // Display year to screen
    cout << year << endl;

    for(int i=1; i<13; i++)
    {
        // Calculating result
        WS = CalcAvgMonthWindSpeed(app, i, year);
        deg = CalcAvgMonthTemp(app, i, year);

        // Convert month to string format
        d.ConvertMonth(i, temp);

        // Displaying calculated result
        if(WS > 0 && deg > 0)
        {
            cout << fixed << setprecision(1);
            cout << temp << ": " << WS << " km/h, ";
            cout << deg << " degrees C" << endl;
        }
        else
        {
            cout << temp << ": No Data" << endl;
        }
    }
}

// Function for option 3
void Application::Option3(Application &app)
{
    int year=0;     // Variable to store year

    // Getting year input
    while(year == 0)
    {
        cout << "Enter year: ";
        year = YearInput();
    }

    Date d;     // Creating date to convert month into string format
    float sr;   // Variable to store solar radiation

    // Displaying year to screen
    cout << year << endl;

    for(int i=1; i<13; i++)
    {
        // Calculating result
        sr = CalcTotalMonthSolar(app, i, year);

        // Converting month to string format
        d.ConvertMonth(i, temp);

        // Displaying result
        if(sr > 0)
        {
            cout << fixed << setprecision(1);
            cout << temp << ": " << sr << " kWh/m^2" << endl;
        }
        else
        {
            cout << temp << ": No Data" << endl;
        }
    }
}

// Function to calculate average monthly solar radiation
float Application::CalcTotalMonthSolar(Application &app, int m, int y)
{
    float sr=0;                         // Variable to store temperature
    int counter=0;                      // Variable to count number records found
    WindTempSolarLog temp_log;          // Temporary log to store records retrieved
    bool check = true;                  // Variable used as a flag for duplicated records
    WindTempSolarLog duplicate_log;     // Log to store records retrieved to check for duplicates
    Date d;                             // Creating date to convert month into string format

    // Converting year and month input into key
    d.ConvertMonth(m, temp);
    temp = temp + to_string(y);

    // Iterate through map to look for specified records
    for(m_map_itr = m_map_log.begin(); m_map_itr != m_map_log.end(); ++m_map_itr)
    {
        // If record is found
        if(m_map_itr->first == temp)
        {
            // Retrieving value from map
            temp_log = m_map_itr->second;

            // Set iterator m_first to position of first record found
            if(counter == 0)
            {
                m_first = m_map_itr;
            }

            // Check for duplicate records
            for(m_duplicate_itr = m_first; m_duplicate_itr != m_map_itr; ++m_duplicate_itr)
            {
                duplicate_log = m_duplicate_itr->second;

                if(m_duplicate_itr->first == temp && duplicate_log.GetDate() == temp_log.GetDate() && duplicate_log.GetTime() == temp_log.GetTime())
                {
                    check = false;
                }
            }

            // Calculate only if record is not duplicated and valid
            if(check && temp_log.GetSolarRadiation() >= 100)
            {
                sr += temp_log.GetSolarRadiation();
                counter++;
            }

            // Reset check
            check = true;
        }
    }

    if(counter > 0)
    {
        // Converting to kWh/m^2
        return sr/6/1000;
    }
    else
    {
        return 0;
    }
}

// Function to add result to output into private string m_result
void Application::AddToResult(string s)
{
    m_result += s;
}

// Function to access private string m_result
void Application::GetResult(string &s) const
{
    s = m_result;
}

// Function for option 4
void Application::Option4(Application &app)
{
    int year=0;     // Variable to store year

    // Get user input
    while(year == 0)
    {
        cout << "Enter year: ";
        year = YearInput();
    }

    // Display to screen to let user know that the program is still running
    cout << "Processing...";

    Date d;             // Creating date to convert month into string format
    float ws, deg, sr;  // Variables to store wind speed, temperature and solar radiation respectively
    int count=0;        // Variable to count number of outputs

    // Adding year to m_result
    app.AddToResult(to_string(year) + "\n");

    for(int i=1; i<13; i++)
    {

        // Calculating results
        ws = CalcAvgMonthWindSpeed(app, i, year);
        deg = CalcAvgMonthTemp(app, i, year);
        sr = CalcTotalMonthSolar(app, i, year);

        // Adding calculated result into m_result
        if(ws > 0 && deg > 0 && sr > 0)
        {
            // Converting month to string format
            d.ConvertMonth(i, temp);

            // Adding month to m_result
            app.AddToResult(temp + ",");

            // Adding calculated result to m_result
            app.AddToResult(to_string(ws) + "," + to_string(deg) + "," + to_string(sr) + "\n");

            count ++;
        }

        // Display to screen to let user know that the program is still running
        cout << ".";
    }

    // Add No Data to result only if all months do not have data
    if(count == 0)
    {
        app.AddToResult("No Data\n");
    }

    // Output m_result into output file
    OutputResult(app);

    // Display to screen to let user know that the task has been completed
    cout << "Complete.";
    cout << "\n\nData output into file WindTempSolar.csv successfully." << endl;

    // Clear result after output is completed
    m_result = "";
}

// Function to output result into csv file
void Application::OutputResult(Application &app)
{
    // Opening output file
    ofstream ofile("WindTempSolar.csv");

    // Streaming output into file
    ofile << app;

    // Closing file
    ofile.close();
}

// Function to add key-value pair into m_map_log
void Application::InsertToMap(const string key, const WindTempSolarLog value)
{
    m_map_log.insert(pair <string, WindTempSolarLog> (key, value));
}

// Function to add key into m_bst
void Application::InsertToBst(string key)
{
    m_bst.Insert(key);
}

// Function to check if date input by user is valid
bool Application::DateInput(int &d, int &m, int &y)
{
    bool check;     // Variable is used as a flag for valid date
    Date dTemp;     // Creating date to convert month into string format and to check for valid date

    // Prompt for input
    cout << "Enter date [d/m/yyyy]: ";

    try
    {
        // Getting input and converting them into integer
        getline(cin, temp, '/');
        d = stoi(temp);

        getline(cin, temp, '/');
        m = stoi(temp);

        getline(cin, temp);
        y = stoi(temp);

        // Check for valid date
        check = dTemp.ValidDate(d, m, y);

        // Display error message if date is invalid
        if(!check)
        {
            cout << "\nInvalid date" << endl;
            return false;
        }

        // Convert month to string format
        dTemp.ConvertMonth(m, temp);

        // Check if date entered is a valid date
        check = m_bst.Search(temp + to_string(y));

        // Display error message if date is not in program
        if(!check)
        {
            cout << "\nProgram does not contain records for the date " << d << "/" << m << "/" << y << endl;
            return false;
        }
    }
    catch(...)
    {
        cout << "\nInvalid input" << endl;
        cin.ignore();
        return false;
    }

    return true;
}

// Function to option 5
void Application::Option5(Application &app)
{
    int d, m, y;    // Variables to store day, month and year of date respectively
    bool check;     // Variable used as a flag for invalid input; also used to flag duplicate records

    // Getting date input and checking if it is valid
    check = app.DateInput(d, m, y);

    // Only execute if date is valid
    if(check)
    {
        int highestSolarRadiation;          // Variable to store highest solar radiation
        int counter = 0;                    // Variable to count number of records found
        WindTempSolarLog temp_log;          // Temporary log to store records retrieved
        WindTempSolarLog duplicate_log;     // Log to store records retrieved to check for duplicates
        Date dTemp;                         // Creating date to convert month into string format

        // Converting year and month input into key
        dTemp.ConvertMonth(m, temp);
        temp = temp + to_string(y);

        // Iterate through map and look for specified records
        for(m_map_itr = m_map_log.begin(); m_map_itr != m_map_log.end(); ++m_map_itr)
        {
            // If year and month entered by user is found
            if(m_map_itr->first == temp)
            {
                // Retrieving value from map
                temp_log = m_map_itr->second;

                // If record found has the same day as user input day
                if(temp_log.GetDate().GetDay() == d)
                {
                    // Set iterator m_first to position of first record found
                    if(counter == 0)
                    {
                        m_first = --m_map_itr;
                    }

                    // Check for duplicate records
                    for(m_duplicate_itr = m_first; m_duplicate_itr != m_map_itr; ++m_duplicate_itr)
                    {
                        duplicate_log = m_duplicate_itr->second;

                        if(m_duplicate_itr->first == temp && duplicate_log.GetDate() == temp_log.GetDate() && duplicate_log.GetTime() == temp_log.GetTime())
                        {
                            check = false;
                        }
                    }

                    // If record is not duplicate
                    if(check)
                    {
                        // If record found is the first record
                        if(counter == 0)
                        {
                            // Set highest solar radiation
                            highestSolarRadiation = temp_log.GetSolarRadiation();

                            // Store time of record into m_result
                            m_result = "Time:\n" + to_string(temp_log.GetTime().GetHour()) + ":" + to_string(temp_log.GetTime().GetMinute()) + "\n";
                        }
                        // If record found has higher solar radiation than highestSolarRadiation
                        else if(highestSolarRadiation < temp_log.GetSolarRadiation())
                        {
                            // Set highest solar radiation to record's value
                            highestSolarRadiation = temp_log.GetSolarRadiation();

                            // Store time of record into m_result
                            m_result = "Time:\n" + to_string(temp_log.GetTime().GetHour()) + ":" + to_string(temp_log.GetTime().GetMinute()) + "\n";
                        }
                        // If record found has the same solar radiation as highestSolarRadiation
                        else if(highestSolarRadiation == temp_log.GetSolarRadiation())
                        {
                            // Add time of record into m_result
                            m_result += to_string(temp_log.GetTime().GetHour()) + ":" + to_string(temp_log.GetTime().GetMinute()) + "\n";
                        }

                        counter++;
                    }

                    // Reset check
                    check = true;
                }
            }
        }

        // Display result onto screen
        if(counter != 0)
        {
            cout << "\nDate: " << d << "/" << m << "/" << y << endl;
            cout << "Highest solar radiation for the day: " << highestSolarRadiation << " W/m^2" << endl << endl;
            cout << m_result;
        }
        // Display error message if not found
        else
        {
            cout << "\nProgram does not contain records for the date " << d << "/" << m << "/" << y << endl;
        }

        // Reset m_result
        m_result = "";
    }
}

// Overloaded input operator
istream & operator >>(istream &input, Application &A)
{
    bool check = true;  // Check if record is valid
    string temp;        // Variable to store temporary values

    // Indicate to user that program is still extracting data from file
    cout << ".";

    // Clearing first line
    getline(input, temp);

    while(getline(input,temp))
    {
        // Streaming input data from file back into stream
        stringstream ss(temp);

        // Creating WindTempSolarLog to store data
        WindTempSolarLog log;

        // Discard record if it is invalid
        try
        {
            // Creating Date to store date data
            Date d;

            // Getting date values from stream and storing them into Date created
            getline(ss, temp, '/');
            d.SetDay(stoi(temp));

            getline(ss, temp, '/');
            d.SetMonth(stoi(temp));

            getline(ss, temp, ' ');
            d.SetYear(stoi(temp));

            // Store filled Date into WindTempSolarLog
            log.SetDate(d);

            // Creating Time to store time data
            Time t;

            // Getting time values from stream and storing them into Time
            getline(ss, temp, ':');
            t.SetHour(stoi(temp));

            getline(ss, temp, ',');
            t.SetMinute(stoi(temp));

            // Store filled Time into WindTempSolarLog
            log.SetTime(t);

            // Removing extra information in input file
            for (int i =0; i<9; i++)
            {
                getline(ss, temp, ',');
            }

            // Getting wind speed data and storing it into WindTempSolarLog
            getline(ss, temp, ',');
            log.SetWindSpeed(stof(temp));

            // Getting solar radiation data and storing it into WindTempSolarLog
            getline(ss, temp, ',');
            log.SetSolarRadiation(stof(temp));

            // Removing extra information in input file
            for (int i =0; i<5; i++)
            {
                getline(ss, temp, ',');
            }

            // Getting temperature data and storing it into WindTempSolarLog
            getline(ss, temp, '\n');
            log.SetTemperature(stof(temp));
        }
        catch(...)
        {
            check = false;
        }

        if (check == true)
        {
            // Getting key in the form of monthYear eg. May2010
            log.GetDate().ConvertMonth(log.GetDate().GetMonth(), temp);
            temp = temp + to_string(log.GetDate().GetYear());

            // Insert key and log into map
            A.InsertToMap(temp, log);

            // Insert key into bst
            A.InsertToBst(temp);
        }

        // Reset check
        check = true;
    }

    return input;
}

// Overloaded output operator
ostream & operator <<(ostream &output, const Application &A)
{
    string temp;

    // Retrieving result to output
    A.GetResult(temp);

    // Streaming result into output file
    output << temp;

    return output;
}
