#ifndef BSTTEST_H
#define BSTTEST_H

#include <iostream>
#include "Bst.h"
#include "Date.h"

using namespace std;

/**
 * @class BstTest
 * @brief  Test all functions in Bst class
 *
 *
 * @author Zhi Guang
 * @version 01
 * @date 12/03/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 15/03/2020 Zhi Guang, Added test for function pointer
 *
 * @author Zhi Guang
 * @version 03
 * @date 16/03/2020 Zhi Guang, Added test for GetData function
 *
 * @bug The program has no bugs
 */

class BstTest
{
    public:
        BstTest();
        virtual ~BstTest();

        void Test1();
        void Test2();
        void Test3();
        void Test4();
        void Test5();
        void Test6();
        void Test7();
        void Test8();
        void Test9();
        void Test10();
        void Test11();
        void Test12();
        void Test13();
        void Test14();
        void Test15();
        void Test16();
        void Test17();
        void Test18();
        void Test19();
        void Test20();
        void Test21();
        void Test22();
        void Test23();

    protected:

    private:
};

// Function to add 5 to all nodes in tree
void AddToNode(int &item);

#endif // BSTTEST_H
