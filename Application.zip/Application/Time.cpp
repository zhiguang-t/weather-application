#include "Time.h"

Time::Time()
{}

Time::~Time()
{}

void Time::SetHour(int h)
{
    m_hour = h;
}

int Time::GetHour() const
{
    return m_hour;
}

void Time::SetMinute(int m)
{
    m_min = m;
}

int Time::GetMinute() const
{
    return m_min;
}

istream & operator >>( istream &input, Time &T)
{
    return input;
}

ostream & operator <<(ostream &output, const Time &T)
{
    return output;
}

bool operator ==(const Time &L, const Time &R)
{
    return (L.GetHour() == R.GetHour() && L.GetMinute() == R.GetMinute());
}
