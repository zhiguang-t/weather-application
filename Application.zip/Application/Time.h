#ifndef TIME_H
#define TIME_H

#include <iostream>
#include <string>

using namespace std;

/**
 * @class Time
 * @brief Manage all time
 *
 * @author Zhi Guang
 * @version 01
 * @date 23/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 03
 * @date 05/04/2020 Zhi Guang, Added comparison operator
 *
 * @bug The program has no bugs
 */

class Time
{
    public:
        /**
         * @brief Default constructor
         */
        Time();

        /**
         * @brief Default destructor
         */
        virtual ~Time();

        /**
         * @brief Set hour of time
         *
         * @return void
         */
         void SetHour(int h);

         /**
         * @brief Get hour of time
         *
         * @return m_hour - hour of time
         */
         int GetHour() const;

         /**
         * @brief Set minute of time
         *
         * @return void
         */
         void SetMinute(int m);

         /**
         * @brief Get minute of time
         *
         * @return m_min - minute of time
         */
         int GetMinute() const;

    protected:

    private:
        /// Hour of time
        int m_hour;
        /// Minute of time
        int m_min;
};

istream & operator >>( istream &input, Time &T);

ostream & operator <<(ostream &output, const Time &T);

bool operator ==(const Time &L, const Time &R);

#endif // TIME_H
