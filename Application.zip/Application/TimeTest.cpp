#include "TimeTest.h"

TimeTest::TimeTest()
{
    cout << "---------------------------------------------------" << endl;
    cout << "Tests for Time class" << endl;;
    cout << "---------------------------------------------------" << endl << endl;
}

TimeTest::~TimeTest()
{}

void TimeTest::Test1()
{
    cout << "Test 1 - Create Time class" << endl;
    Time t;
    cout << "Time created" << endl << endl << endl;
}

void TimeTest::Test2()
{
    cout << "Test 2 - Test setter and getter functions" << endl;
    Time t;
    t.SetHour(30);
    t.SetMinute(20);
    cout << "Hour set to 30, minute set to 20" << endl;
    cout << "Hour: " << t.GetHour() << "\nMinute: " << t.GetMinute() << endl << endl;

    t.SetHour(-12);
    t.SetMinute(70);
    cout << "Hour set to -12, minute set to 70" << endl;
    cout << "Hour: " << t.GetHour() << "\nMinute: " << t.GetMinute() << endl << endl;
    cout << "Hour and minute can be set to invalid values as no error checking was done" << endl << endl;

    cout << "All tests pass" << endl << endl << endl;
}

void TimeTest::Test3()
{
    cout << "Test 3 - Test comparison operator" << endl;

    bool check;

    Time t1;
    t1.SetHour(30);
    t1.SetMinute(20);
    cout << "Hour set to 30, minute set to 20 for time 1" << endl << endl;

    Time t2;
    t2.SetHour(30);
    t2.SetMinute(20);
    cout << "Hour set to 30, minute set to 20 for time 2" << endl << endl;

    Time t3;
    t3.SetHour(50);
    t3.SetMinute(20);
    cout << "Hour set to 50, minute set to 20 for time 3" << endl << endl;

    check = t1 == t2;
    cout << "Comparing if time 1 equals time 2: Expected: 1 Actual: " << check << endl << endl;

    check = t1 == t3;
    cout << "Comparing if time 1 equals time 3: Expected: 0 Actual: " << check << endl << endl;

    cout << "All tests pass" << endl << endl << endl;
}
