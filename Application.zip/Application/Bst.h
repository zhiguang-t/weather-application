#ifndef BST_H
#define BST_H

#include <iostream>

using namespace std;

/**
 * @class Bst
 * @brief  Create a binary search tree that can hold specified data type
 *
 *
 * @author Zhi Guang
 * @version 01
 * @date 12/03/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 15/03/2020 Zhi Guang, Added Traversal function (function pointer)
 *
 * @author Zhi Guang
 * @version 03
 * @date 16/03/2020 Zhi Guang, Added GetData function
 *
 * @bug The program has no bugs
 */

template <class T>
class Bst
{
    public:
        /**
         * @brief Constructor
         *
         * Initialise root pointer to null
         */
        Bst();

        /**
         * @brief Destructor
         *
         * Delete all nodes in tree
         */
        virtual ~Bst();

        /**
         * @brief Insert new node into BST
         *
         * @param newData - data to insert into node
         * @return void
         */
        void Insert(const T newData);

        /**
         * @brief Delete node containing item passed into parameter
         *
         * Node containing item, along with all children nodes will be deleted
         *
         * @param item - item to delete
         * @return void
         */
        void Delete(const T item);

        /**
         * @brief Traverse the tree in-order
         *
         * Prints out data in tree from smallest to largest
         *
         * @return void
         */
        void InOrder() const;

        /**
         * @brief Traverse the tree in pre-order
         *
         * Prints out data in the tree in pre-order format.
         *
         * @return void
         */
        void PreOrder() const;

        /**
         * @brief Traverse the tree in post-order
         *
         * Prints out data in the tree in post-order format.
         *
         * @return void
         */
        void PostOrder() const;

        /**
         * @brief Search for item in tree
         *
         * @return true if item is found; false otherwise
         */
        bool Search(const T &item);

        /**
         * @brief Returns data of node containing item
         *
         * @param &item - item to search for
         * @param &store - variable to store item retrieved from tree
         * @return true if item is found; false otherwise
         */
        bool GetData(const T &item, T &store);

        /**
         * @brief Traverse tree in order, and performs function on data of every node
         *
         * @return void
         */
        void Traversal(void(*funcPtr)(T &item)) const;

    protected:

    private:
        /// Node of tree
        struct node
        {
            T data;
            node *leftChild;
            node *rightChild;
        };

        /// Node pointer pointing to root node
        node *root;

        /**
         * @brief Insert new node to parent node if the corresponding node is empty
         *
         * Values lesser than the parent node will be inserted into the left child,
         * while values more than the parent will be inserted into the right child.
         * If the value already exists, it will not be inserted into the tree.
         *
         * @param newNode - pointer to new node to insert
         * @param parent - pointer to parent node
         * @return void
         */
        void Insert(node* newNode, node* parent);

        /**
         * @brief Delete node, along with all children nodes
         *
         * @return void
         */
        void Delete(node *&p);

        /**
         * @brief Recursive function to traverse tree in-order
         *
         * @return void
         */
        void InOrder(node *p) const;

        /**
         * @brief Recursive function to traverse tree pre-order
         *
         * @return void
         */
        void PreOrder(node *p) const;

        /**
         * @brief Recursive function to traverse tree post-order
         *
         * @return void
         */
        void PostOrder(node *p) const;

        /**
         * @brief Search tree and returns a pointer to node containing item
         *
         * @param item - item to search for
         * @return currNode - pointer to node; null pointer if not found
         */
        node* SearchTree(const T &item);

        /**
         * @brief Recursive function to traverse tree in-order and performs function on every node
         *
         * @return void
         */
        void Traversal(node *p, void(*funcPtr)(T &item)) const;
};

// Implementation

template <class T>
Bst<T>::Bst()
{
    root = nullptr;
}

template <class T>
Bst<T>::~Bst()
{
    Delete(root);
}

template <class T>
void Bst<T>::Delete(node *&p)
{
    if(p != nullptr)
    {
        Delete(p->leftChild);
        Delete(p->rightChild);
        delete p;
        p = nullptr;
    }
}

template <class T>
void Bst<T>::Insert(const T newData)
{
    node *newNode = new node;

    // Initialise values of newNode
    newNode->data = newData;
    newNode->leftChild = nullptr;
    newNode->rightChild = nullptr;

    if(root == nullptr)
    {
        root = newNode;
    }
    else
    {
        Insert(newNode, root);
    }
}

template <class T>
void Bst<T>::Insert(node* newNode, node* parent)
{
    if(newNode->data < parent->data)
    {
        if(parent->leftChild == nullptr)
        {
            parent->leftChild = newNode;
        }
        else
        {
            Insert(newNode, parent->leftChild);
        }
    }
    else if(newNode->data > parent->data)
    {
        if(parent->rightChild == nullptr)
        {
            parent->rightChild = newNode;
        }
        else
        {
            Insert(newNode, parent->rightChild);
        }
    }
}

template <class T>
void Bst<T>::InOrder(node *p) const
{
    if(p != nullptr)
    {
        InOrder(p->leftChild);
        cout << p->data << " ";
        InOrder(p->rightChild);
    }
}

template <class T>
void Bst<T>::InOrder() const
{
    InOrder(root);
}

template <class T>
void Bst<T>::PreOrder(node *p) const
{
    if(p != nullptr)
    {
        cout << p->data << " ";
        PreOrder(p->leftChild);
        PreOrder(p->rightChild);
    }
}

template <class T>
void Bst<T>::PreOrder() const
{
    PreOrder(root);
}

template <class T>
void Bst<T>::PostOrder(node *p) const
{
    if(p != nullptr)
    {
        PostOrder(p->leftChild);
        PostOrder(p->rightChild);
        cout << p->data << " ";
    }
}

template <class T>
void Bst<T>::PostOrder() const
{
    PostOrder(root);
}

template <class T>
void Bst<T>::Delete(const T item)
{
    if(root != nullptr)
    {
        bool found = false;
        node *currNode;
        node *trailNode;

        currNode = root;
        trailNode = root;

        while(currNode != nullptr && found != true)
        {
            if(item == currNode->data)
            {
                found = true;
            }
            else if(item < currNode->data)
            {
                trailNode = currNode;
                currNode = currNode->leftChild;
            }
            else
            {
                trailNode = currNode;
                currNode = currNode->rightChild;
            }
        }

        if(found == true)
        {
            if(currNode == root)
            {
                Delete(root);
            }
            else if(currNode->data < trailNode->data)
            {
                Delete(trailNode->leftChild);
            }
            else
            {
                Delete(trailNode->rightChild);
            }
        }
    }
}

template <class T>
typename Bst<T>::node* Bst<T>::SearchTree(const T &item)
{
    bool found = false;
    node *currNode;

    currNode = root;

    while(currNode != nullptr && found != true)
    {
        if(item == currNode->data)
        {
            found = true;
        }
        else if(item < currNode->data)
        {
            currNode = currNode->leftChild;
        }
        else
        {
            currNode = currNode->rightChild;
        }
    }

    if(found == false)
    {
        currNode = nullptr;
    }
    return currNode;
}

template <class T>
bool Bst<T>::Search(const T &item)
{
    return SearchTree(item) != nullptr;
}

template <class T>
bool Bst<T>::GetData(const T &item, T &store)
{
    node *found = SearchTree(item);

    if(found != nullptr)
    {
        store = found->data;
        return true;
    }
    return false;
}

template <class T>
void Bst<T>::Traversal(void(*funcPtr)(T &item)) const
{
    Traversal(root, *funcPtr);
}

template <class T>
void Bst<T>::Traversal(node *p, void(*funcPtr)(T &item)) const
{
    if(p != nullptr)
    {
        Traversal(p->leftChild, *funcPtr);
        (*funcPtr)(p->data);
        Traversal(p->rightChild, *funcPtr);
    }
}

#endif // BST_H
