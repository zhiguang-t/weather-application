#ifndef WINDTEMPSOLARLOG_H
#define WINDTEMPSOLARLOG_H

#include "Date.h"
#include "Time.h"
#include <iostream>

using namespace std;

/**
 * @class WindTempSolarLog
 * @brief Manage all log information from input file
 *
 * @author Zhi Guang
 * @version 01
 * @date 26/02/2020 Zhi Guang, Started
 *
 * @author Zhi Guang
 * @version 02
 * @date 05/04/2020 Zhi Guang, Changed naming of member variables
 *
 * @bug The program has no bugs
 */

class WindTempSolarLog
{
    public:
        /**
         * @brief Default constructor
         */
        WindTempSolarLog();

        /**
         * @brief Default destructor
         */
        virtual ~WindTempSolarLog();

        /**
         * @brief Set WindTempSolarLog
         *
         * Sets value of WindTempSolarLog to that of the values of w passed into parameter
         *
         * @param w - WindTempSolarLog to set values to
         * @return void
         */
        void SetWindTempSolarLog(WindTempSolarLog w);

        /**
         * @brief Set Date
         *
         * @param d - Date to set
         * @return void
         */
        void SetDate(Date d);

        /**
         * @brief Set Time
         *
         * @param t - Time to set
         * @return void
         */
        void SetTime(Time t);

        /**
         * @brief Set wind speed
         *
         * @param w - wind speed to set
         * @return void
         */
        void SetWindSpeed(float w);

        /**
         * @brief Set solar radiation
         *
         * @param s - solar radiation to set
         * @return void
         */
        void SetSolarRadiation(float s);

        /**
         * @brief Set temperature
         *
         * @param t - temperature to set
         * @return void
         */
        void SetTemperature(float t);

        /**
         * @brief Return Date
         *
         * @return m_date - Date
         */
        Date GetDate() const;

        /**
         * @brief Return Time
         *
         * @return m_time - Time
         */
        Time GetTime() const;

        /**
         * @brief Return wind speed
         *
         * @return m_wind_speed - wind speed
         */
        float GetWindSpeed() const;

        /**
         * @brief Return solar radiation
         *
         * @return m_solar - solar radiation
         */
        float GetSolarRadiation() const;

        /**
         * @brief Return temperature
         *
         * @return m_temp - temperature
         */
        float GetTemperature() const;

    protected:

    private:
        /// Store Date
        Date m_date;
        /// Store Time
        Time m_time;
        /// Store wind speed
        float m_wind_speed;
        /// store solar radiation
        float m_solar_radiation;
        /// store temperature
        float m_temperature;
};

#endif // WINDTEMPSOLARLOG_H
