#include <iostream>
#include "Application.h"
#include "AllUnitTests.h"

using namespace std;

int main()
{
    // Creating Application
    Application a;

    // Replace string with file for application to read
    bool check = a.OpenFile("data/met_index.txt", a);

    // Running application
    a.RunApp(a, check);


    //-----------------------------------------
    // UNIT TESTING
    //-----------------------------------------

    /* Uncomment below to run all unit tests */
    //AllUnitTests t;
    //t.Test();
}
