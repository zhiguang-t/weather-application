#include "DateTest.h"

DateTest::DateTest()
{
    cout << "---------------------------------------------------" << endl;
    cout << "Tests for Date class" << endl;;
    cout << "---------------------------------------------------" << endl << endl;
}

DateTest::~DateTest()
{}

void DateTest::Test1()
{
    cout << "Test 1 - Create Date class" << endl;
    Date d;
    cout << "Date created" << endl << endl << endl;
}

void DateTest::Test2()
{
    cout << "Test 2 - Testing setter and getter functions for day, month and year" << endl;
    Date d;
    d.SetDay(5);
    d.SetMonth(3);
    d.SetYear(2020);
    cout << "Setting the date 5/3/2020" << endl << endl;

    cout << "Day: " << d.GetDay() << endl;
    cout << "Month: " << d.GetMonth() << endl;
    cout << "Year: " << d.GetYear() << endl << endl;

    Date d2(-2, 23, -213);
    cout << "Setting the date -1/23/-213" << endl << endl;

    cout << "Day: " << d2.GetDay() << endl;
    cout << "Month: " << d2.GetMonth() << endl;
    cout << "Year: " << d2.GetYear() << endl << endl;

    cout << "Invalid date still saved as no error checking is done" << endl << endl;
    cout << "All tests pass" << endl << endl << endl;
}

void DateTest::Test3()
{
    cout << "Test 3 - Testing ConvertMonth function" << endl;
    Date d;
    string dName;

    d.ConvertMonth(1, dName);
    cout << "Converting integer month : 1" << endl;
    cout << "Result: " << dName << endl << endl;

    d.ConvertMonth(13, dName);
    cout << "Converting integer month : 13" << endl;
    cout << "Result: " << dName << endl << endl << endl;
}

void DateTest::Test4()
{
    cout << "Test 4 - Testing comparison operators" << endl;
    bool check;
    Date d1(2,2,2010);
    Date d2(2,2,2010);
    Date d3(1,2,2010);
    Date d4(3,1,2010);
    Date d5(3,3,2009);

    check = d1 == d2;
    cout << "Comparing if " << d1 << " and " << d2 << " are equal. Expected: 1 Actual: " << check << endl << endl;


    check = d1 == d3;
    cout << "Comparing if " << d1 << " and " << d3 << " are equal. Expected: 0 Actual: " << check << endl << endl;

    check = d1 > d2;
    cout << "Checking if " << d1 << " is bigger than " << d2 << ". Expected: 0 Actual: " << check << endl << endl;

    check = d1 > d3;
    cout << "Checking if " << d1 << " is bigger than " << d3 << ". Expected: 1 Actual: " << check << endl << endl;

    check = d1 > d4;
    cout << "Checking if " << d1 << " is bigger than " << d4 << ". Expected: 1 Actual: " << check << endl << endl;

    check = d1 > d5;
    cout << "Checking if " << d1 << " is bigger than " << d5 << ". Expected: 1 Actual: " << check << endl << endl;

    check = d1 < d2;
    cout << "Checking if " << d1 << " is smaller than " << d2 << ". Expected: 0 Actual: " << check << endl << endl;

    check = d3 < d1;
    cout << "Checking if " << d3 << " is smaller than " << d1 << ". Expected: 1 Actual: " << check << endl << endl;

    check = d4 < d1;
    cout << "Checking if " << d4 << " is smaller than " << d1 << ". Expected: 1 Actual: " << check << endl << endl;

    check = d5 < d1;
    cout << "Checking if " << d5 << " is smaller than " << d1 << ". Expected: 1 Actual: " << check << endl << endl;

    cout << "All tests pass" << endl << endl << endl;
}

void DateTest::Test5()
{
    cout << "Test 5 - Testing ValidDate function" << endl;
    Date d;
    bool check;

    check = d.ValidDate(15,1,2014);
    cout << "Checking date: 15/1/2014" << endl;
    cout << "Result: Expected: 1 Actual: " << check << endl << endl;

    check = d.ValidDate(33,1,2014);
    cout << "Checking date: 33/1/2014" << endl;
    cout << "Result: Expected: 0 Actual: " << check << endl << endl;

    check = d.ValidDate(-3,1,2014);
    cout << "Checking date: -3/1/2014" << endl;
    cout << "Result: Expected: 0 Actual: " << check << endl << endl;

    check = d.ValidDate(15,0,2000);
    cout << "Checking date: 15/0/2000" << endl;
    cout << "Result: Expected: 0 Actual: " << check << endl << endl;

    check = d.ValidDate(15,13,2000);
    cout << "Checking date: 15/13/2000" << endl;
    cout << "Result: Expected: 0 Actual: " << check << endl << endl;

    check = d.ValidDate(15,3,-12);
    cout << "Checking date: 15/3/-12" << endl;
    cout << "Result: Expected: 0 Actual: " << check << endl << endl;

    check = d.ValidDate(15,3,0);
    cout << "Checking date: 15/3/0" << endl;
    cout << "Result: Expected: 0 Actual: " << check << endl << endl;

    check = d.ValidDate(29,2,2100);
    cout << "Checking date: 29/2/2100" << endl;
    cout << "Result: Expected: 0 Actual: " << check << endl << endl;

    cout << "All tests pass" << endl << endl << endl;
}
